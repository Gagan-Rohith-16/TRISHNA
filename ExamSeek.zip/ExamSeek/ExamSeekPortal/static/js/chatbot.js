// This file is kept for compatibility but is no longer used
// The chatbot functionality is now provided by Dialogflow and embedded in layout.html

document.addEventListener('DOMContentLoaded', function() {
    console.log("Dialogflow integration active - native chatbot replaced");
});